export const handler = async () => {

    const response = {
        status: '200',
        body: 'OK',
    };

    return response;
};
